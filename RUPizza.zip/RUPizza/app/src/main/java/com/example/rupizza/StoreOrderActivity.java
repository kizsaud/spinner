package com.example.rupizza;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
public class StoreOrderActivity extends AppCompatActivity {
    private TextView textView5;
    private Spinner orderNumberSpinner;
    private TextView orderTotalTextView;
    private ListView orderViewListView;
    private Order order;
    private static final DecimalFormat df = new DecimalFormat("0.00");


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_order);
        ActionBar actionBar = getSupportActionBar();


        // showing the back button in action bar
        textView5=findViewById(R.id.textView5);
        actionBar.setDisplayHomeAsUpEnabled(true);
        textView5.setText("Order Number:");





        orderNumberSpinner = findViewById(R.id.orderNumberSpinner);
        ImageView btnCancelOrder = findViewById(R.id.btnCancelOrder);
        orderTotalTextView = findViewById(R.id.orderTotalTextView);
        orderViewListView = findViewById(R.id.orderViewListView);

        orderNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                order = StoreOrder.getOrder(Integer.parseInt(orderNumberSpinner.getSelectedItem().toString()));
                orderTotalTextView.setText(df.format(order.getTotal()));
                updateList();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                ArrayList<Integer> orderNums = StoreOrder.getOrderIDs();
                if(orderNums.size() > 0){
                    orderNumberSpinner.setSelection(0);
                    order = StoreOrder.getOrder(Integer.parseInt(orderNumberSpinner.getSelectedItem().toString()));
                }
            }
        });

        btnCancelOrder.setOnClickListener(v -> {
            if(orderNumberSpinner.getSelectedItem() == null){
                Toast.makeText(StoreOrderActivity.this,
                        "No Order Selected", Toast.LENGTH_SHORT).show();
                return;
            }
            int orderNum = Integer.parseInt(orderNumberSpinner.getSelectedItem().toString());
            StoreOrder.cancel(orderNum);
            Toast.makeText(StoreOrderActivity.this,
                    "Order " + orderNum + " cancelled", Toast.LENGTH_SHORT).show();
            init();
        });

        init();
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }



    private void init(){
        ArrayAdapter<Integer> orderNumAdapter = new ArrayAdapter<>(StoreOrderActivity.this,
                android.R.layout.simple_spinner_dropdown_item,
                StoreOrder.getOrderIDs());
        orderNumAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        orderNumberSpinner.setAdapter(orderNumAdapter);

        if(StoreOrder.getOrderIDs().size() > 0){
            orderNumberSpinner.setSelection(0);
            order = StoreOrder.getOrder(Integer.parseInt(orderNumberSpinner.getSelectedItem().toString()));
            updateList();
        }
        else{
            clearList();
        }
    }

    private void updateList(){
        ArrayAdapter<Pizza> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                order.getPizzas());
        orderViewListView.setAdapter(arrayAdapter);
    }


    private void clearList(){
        order = null;
        ArrayAdapter<Pizza> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                new ArrayList<>());
        orderViewListView.setAdapter(arrayAdapter);
        String no_cost = "0.00";
        orderTotalTextView.setText(no_cost);
    }
}