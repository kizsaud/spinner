package com.example.rupizza;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity{

    private Button chicagoButton;
    private Button NYButton;
    private Button CartView;
    private Button StoreView;
    private boolean Chicity;
    private boolean mainAct;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chicagoButton = (Button) findViewById(R.id.chicago);
        NYButton = (Button) findViewById(R.id.newyork);
        CartView = findViewById(R.id.CartView);

        StoreView = findViewById(R.id.storeView);
        StoreView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I = new Intent(MainActivity.this,StoreOrderActivity.class);
                startActivity(I);


            }
        });
        CartView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, CartActivity.class);
                startActivity(i);
            }
        });


        chicagoButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mainAct=true;
                Chicity = true;
                openChicago();
            }
        });

        NYButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mainAct=true;
                Chicity = false;
                openNewYork();
            }
        });

    }
    public void openVart(){
        Intent intent = new Intent(this,CartActivity.class);
        startActivity(intent);
    }
    public void openChicago() {
        Intent intent = new Intent(this, ChicagoPizzaActivity.class);
        intent.putExtra("Chicago", Chicity);
        intent.putExtra("main",mainAct);
        startActivity(intent);
    }

    public void openNewYork() {
        Intent intent = new Intent(this, NewYorkActivity.class);
        intent.putExtra("Chicago",Chicity);
        intent.putExtra("main",mainAct);

        startActivity(intent);
    }
}