package com.example.rupizza;

/**
 * Enum for different kinds of crusts
 * @author Abhijeet Singh, Khizar Saud
 */
public enum Crust {
    deepdish,pan,stuffed,brooklyn,thin,handtossed

}
