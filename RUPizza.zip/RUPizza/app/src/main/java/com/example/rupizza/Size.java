package com.example.rupizza;

/**
 * Size enum for pizza sizes.
 * @author Abhijeet Singh, Khizar Saud
 */
public enum Size {
    small,large,medium


}
